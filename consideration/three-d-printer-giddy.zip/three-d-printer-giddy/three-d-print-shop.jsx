import React, { useState } from 'react';
import { Printer, Upload, Search, Box, Users, Clock, CheckCircle, AlertCircle } from 'lucide-react';

// API Stubs - Ready for real integration
const ThingiVerseAPI = {
  search: async (query) => {
    // STUB: Replace with actual Thingiverse API call
    // GET https://api.thingiverse.com/search/{term}?access_token={token}
    console.log(`[Thingiverse API STUB] Searching: ${query}`);
    return [
      { id: 'tv-001', name: 'Phone Stand v2', creator: 'maker123', thumbnail: '📱', downloads: 15420 },
      { id: 'tv-002', name: 'Pencil Holder', creator: 'eduprint', thumbnail: '✏️', downloads: 8930 },
      { id: 'tv-003', name: 'Cable Organizer', creator: 'deskmaster', thumbnail: '🔌', downloads: 22100 },
    ];
  },
  getDesign: async (id) => {
    console.log(`[Thingiverse API STUB] Fetching design: ${id}`);
    return { id, stlUrl: `https://thingiverse.com/download/${id}` };
  }
};

const TinkerCADAPI = {
  getProjects: async (userId) => {
    // STUB: Replace with actual TinkerCAD API call
    // TinkerCAD uses Autodesk authentication
    console.log(`[TinkerCAD API STUB] Fetching projects for: ${userId}`);
    return [
      { id: 'tc-001', name: 'My Robot Arm', modified: '2025-01-15', thumbnail: '🤖' },
      { id: 'tc-002', name: 'Science Fair Trophy', modified: '2025-01-10', thumbnail: '🏆' },
      { id: 'tc-003', name: 'Custom Keychain', modified: '2025-01-08', thumbnail: '🔑' },
    ];
  },
  exportSTL: async (projectId) => {
    console.log(`[TinkerCAD API STUB] Exporting STL: ${projectId}`);
    return { stlUrl: `https://tinkercad.com/export/${projectId}.stl` };
  }
};

export default function PrintOrderSystem() {
  const [activeTab, setActiveTab] = useState('new-order');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [tinkerProjects, setTinkerProjects] = useState([]);
  const [orders, setOrders] = useState([
    { id: 1, student: 'Alex M.', item: 'Phone Stand', status: 'printing', submitted: '2025-01-17', color: 'Blue' },
    { id: 2, student: 'Jordan K.', item: 'Pencil Holder', status: 'queued', submitted: '2025-01-18', color: 'Red' },
  ]);
  const [newOrder, setNewOrder] = useState({
    studentName: '',
    teacherEmail: '',
    projectName: '',
    source: 'upload',
    sourceId: '',
    color: 'White',
    quantity: 1,
    notes: ''
  });

  const handleThingiverseSearch = async () => {
    const results = await ThingiVerseAPI.search(searchQuery);
    setSearchResults(results);
  };

  const handleLoadTinkerCAD = async () => {
    const projects = await TinkerCADAPI.getProjects('student@school.edu');
    setTinkerProjects(projects);
  };

  const handleSubmitOrder = (e) => {
    e.preventDefault();
    const order = {
      id: orders.length + 1,
      student: newOrder.studentName,
      item: newOrder.projectName,
      status: 'pending',
      submitted: new Date().toISOString().split('T')[0],
      color: newOrder.color
    };
    setOrders([order, ...orders]);
    setNewOrder({
      studentName: '',
      teacherEmail: '',
      projectName: '',
      source: 'upload',
      sourceId: '',
      color: 'White',
      quantity: 1,
      notes: ''
    });
    alert('✅ Order submitted! Awaiting approval.');
  };

  const selectDesign = (design, source) => {
    setNewOrder({
      ...newOrder,
      projectName: design.name,
      source: source,
      sourceId: design.id
    });
    setActiveTab('new-order');
  };

  const StatusBadge = ({ status }) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      queued: 'bg-blue-100 text-blue-800',
      printing: 'bg-purple-100 text-purple-800',
      complete: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/30 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-cyan-500 to-purple-500 p-2 rounded-xl">
                <Printer className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">MakerSpace Print Lab</h1>
                <p className="text-cyan-400 text-sm">School 3D Print Ordering System</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <Clock className="w-4 h-4" />
              <span>Queue: {orders.filter(o => o.status !== 'complete').length} jobs</span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-black/20 border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex gap-1">
            {[
              { id: 'new-order', label: 'New Order', icon: Box },
              { id: 'thingiverse', label: 'Thingiverse', icon: Search },
              { id: 'tinkercad', label: 'TinkerCAD', icon: Users },
              { id: 'queue', label: 'Print Queue', icon: Clock },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 font-medium transition-all ${
                  activeTab === tab.id
                    ? 'text-cyan-400 border-b-2 border-cyan-400 bg-white/5'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        
        {/* New Order Form */}
        {activeTab === 'new-order' && (
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Box className="w-5 h-5 text-cyan-400" />
              Submit Print Order
            </h2>
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Student Name *</label>
                  <input
                    type="text"
                    required
                    value={newOrder.studentName}
                    onChange={e => setNewOrder({...newOrder, studentName: e.target.value})}
                    className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-cyan-500"
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Teacher Email *</label>
                  <input
                    type="email"
                    required
                    value={newOrder.teacherEmail}
                    onChange={e => setNewOrder({...newOrder, teacherEmail: e.target.value})}
                    className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-cyan-500"
                    placeholder="teacher@school.edu"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Project Name *</label>
                <input
                  type="text"
                  required
                  value={newOrder.projectName}
                  onChange={e => setNewOrder({...newOrder, projectName: e.target.value})}
                  className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-cyan-500"
                  placeholder="What are you printing?"
                />
                <p className="text-white/40 text-sm mt-1">
                  Or select from Thingiverse / TinkerCAD tabs above
                </p>
              </div>

              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Design Source</label>
                <div className="flex gap-3">
                  {['upload', 'thingiverse', 'tinkercad'].map(src => (
                    <label key={src} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="source"
                        value={src}
                        checked={newOrder.source === src}
                        onChange={e => setNewOrder({...newOrder, source: e.target.value})}
                        className="text-cyan-500"
                      />
                      <span className="text-white/80 capitalize">{src}</span>
                    </label>
                  ))}
                </div>
              </div>

              {newOrder.source === 'upload' && (
                <div className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center hover:border-cyan-500/50 transition-colors cursor-pointer">
                  <Upload className="w-12 h-12 text-white/40 mx-auto mb-3" />
                  <p className="text-white/60">Drop STL/OBJ file here or click to upload</p>
                  <p className="text-white/40 text-sm mt-1">Max 50MB • STL, OBJ, 3MF</p>
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Filament Color</label>
                  <select
                    value={newOrder.color}
                    onChange={e => setNewOrder({...newOrder, color: e.target.value})}
                    className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white focus:outline-none focus:border-cyan-500"
                  >
                    {['White', 'Black', 'Red', 'Blue', 'Green', 'Yellow', 'Orange', 'Purple'].map(c => (
                      <option key={c} value={c} className="bg-slate-800">{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    value={newOrder.quantity}
                    onChange={e => setNewOrder({...newOrder, quantity: parseInt(e.target.value)})}
                    className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Priority</label>
                  <select className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white focus:outline-none focus:border-cyan-500">
                    <option className="bg-slate-800">Standard (3-5 days)</option>
                    <option className="bg-slate-800">Rush (1-2 days) *</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Notes for Print Tech</label>
                <textarea
                  value={newOrder.notes}
                  onChange={e => setNewOrder({...newOrder, notes: e.target.value})}
                  className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-cyan-500 h-24"
                  placeholder="Any special instructions? Support needs? Orientation preferences?"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-400 hover:to-purple-400 text-white font-bold rounded-xl transition-all transform hover:scale-[1.02]"
              >
                Submit Print Order 🚀
              </button>
            </form>
          </div>
        )}

        {/* Thingiverse Search */}
        {activeTab === 'thingiverse' && (
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Search className="w-5 h-5 text-cyan-400" />
              Search Thingiverse
            </h2>
            <div className="flex gap-3 mb-6">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleThingiverseSearch()}
                className="flex-1 px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-cyan-500"
                placeholder="Search for designs..."
              />
              <button
                onClick={handleThingiverseSearch}
                className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-white font-medium rounded-xl transition-colors"
              >
                Search
              </button>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {searchResults.map(item => (
                <div key={item.id} className="bg-black/30 rounded-xl p-4 border border-white/10 hover:border-cyan-500/50 transition-colors">
                  <div className="text-6xl text-center mb-3">{item.thumbnail}</div>
                  <h3 className="text-white font-medium">{item.name}</h3>
                  <p className="text-white/50 text-sm">by {item.creator}</p>
                  <p className="text-white/40 text-xs mt-1">{item.downloads.toLocaleString()} downloads</p>
                  <button
                    onClick={() => selectDesign(item, 'thingiverse')}
                    className="w-full mt-3 py-2 bg-white/10 hover:bg-cyan-500/30 text-cyan-400 rounded-lg text-sm font-medium transition-colors"
                  >
                    Select for Order
                  </button>
                </div>
              ))}
              {searchResults.length === 0 && (
                <div className="col-span-3 text-center py-12 text-white/40">
                  <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Search Thingiverse for free 3D designs</p>
                </div>
              )}
            </div>
            <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
              <p className="text-yellow-400 text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <strong>API Stub:</strong> Connect your Thingiverse API token in settings
              </p>
            </div>
          </div>
        )}

        {/* TinkerCAD Projects */}
        {activeTab === 'tinkercad' && (
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" />
              My TinkerCAD Projects
            </h2>
            <button
              onClick={handleLoadTinkerCAD}
              className="mb-6 px-6 py-3 bg-purple-500 hover:bg-purple-400 text-white font-medium rounded-xl transition-colors"
            >
              Load My Projects
            </button>
            <div className="grid md:grid-cols-3 gap-4">
              {tinkerProjects.map(project => (
                <div key={project.id} className="bg-black/30 rounded-xl p-4 border border-white/10 hover:border-purple-500/50 transition-colors">
                  <div className="text-6xl text-center mb-3">{project.thumbnail}</div>
                  <h3 className="text-white font-medium">{project.name}</h3>
                  <p className="text-white/50 text-sm">Modified: {project.modified}</p>
                  <button
                    onClick={() => selectDesign(project, 'tinkercad')}
                    className="w-full mt-3 py-2 bg-white/10 hover:bg-purple-500/30 text-purple-400 rounded-lg text-sm font-medium transition-colors"
                  >
                    Select for Order
                  </button>
                </div>
              ))}
              {tinkerProjects.length === 0 && (
                <div className="col-span-3 text-center py-12 text-white/40">
                  <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Connect to load your TinkerCAD designs</p>
                </div>
              )}
            </div>
            <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
              <p className="text-yellow-400 text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <strong>API Stub:</strong> Requires Autodesk OAuth integration
              </p>
            </div>
          </div>
        )}

        {/* Print Queue */}
        {activeTab === 'queue' && (
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-cyan-400" />
              Print Queue
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-white/60 text-sm border-b border-white/10">
                    <th className="pb-3 font-medium">Order</th>
                    <th className="pb-3 font-medium">Student</th>
                    <th className="pb-3 font-medium">Item</th>
                    <th className="pb-3 font-medium">Color</th>
                    <th className="pb-3 font-medium">Submitted</th>
                    <th className="pb-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order.id} className="border-b border-white/5 text-white/80">
                      <td className="py-4 font-mono text-cyan-400">#{order.id.toString().padStart(4, '0')}</td>
                      <td className="py-4">{order.student}</td>
                      <td className="py-4">{order.item}</td>
                      <td className="py-4">
                        <span className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full bg-${order.color.toLowerCase()}-500`} style={{backgroundColor: order.color.toLowerCase()}}></span>
                          {order.color}
                        </span>
                      </td>
                      <td className="py-4 text-white/50">{order.submitted}</td>
                      <td className="py-4"><StatusBadge status={order.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 text-center text-white/40 text-sm">
        <p>MakerSpace Print Lab • Built with 💜 for Maryland Schools</p>
        <p className="mt-1">API Integrations: Thingiverse (stub) • TinkerCAD (stub)</p>
      </footer>
    </div>
  );
}
