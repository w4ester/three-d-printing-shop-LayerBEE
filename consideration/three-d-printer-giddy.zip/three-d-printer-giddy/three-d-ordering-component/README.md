# 🖨️ 3D Print Shop

A simple web-based ordering system for school makerspaces. Students can browse available 3D prints, choose colors, and place orders!

**Built for learning** - Clean HTML/CSS/JS that kids can understand and modify!

---

## 🚀 Quick Start (GitHub Pages)

### Step 1: Create a GitHub Repository
1. Go to [github.com](https://github.com) and sign in
2. Click the **+** button → **New repository**
3. Name it `print-shop` (or whatever you want)
4. Make it **Public**
5. Click **Create repository**

### Step 2: Upload the Files
**Option A: Upload via GitHub web interface**
1. Click **"uploading an existing file"** link
2. Drag ALL the files and folders into the upload area:
   - `index.html`
   - `admin.html`
   - `css/` folder
   - `js/` folder
3. Click **Commit changes**

**Option B: Use Git command line**
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/print-shop.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
1. Go to your repository on GitHub
2. Click **Settings** (gear icon)
3. Scroll down to **Pages** in the left sidebar
4. Under "Source", select **main** branch
5. Click **Save**
6. Wait 1-2 minutes, then visit: `https://YOUR-USERNAME.github.io/print-shop/`

🎉 **Your shop is live!**

---

## 📁 File Structure

```
print-shop/
├── index.html      ← Main shop page (customers see this)
├── admin.html      ← Admin panel (add products, view orders)
├── css/
│   └── style.css   ← All the styling
├── js/
│   ├── data.js     ← Products & colors (EDIT THIS!)
│   ├── app.js      ← Shop functionality
│   └── admin.js    ← Admin panel functionality
└── README.md       ← You're reading this!
```

---

## 🎨 Customizing

### Adding Products (Easy Way)
1. Go to `admin.html` in your browser
2. Click **"+ Add Product"**
3. Fill in the details and save!

### Adding Products (Code Way)
Edit `js/data.js` and add to the `DEFAULT_PRODUCTS` array:

```javascript
{
    id: 7,                              // Unique number
    emoji: "🚀",                        // Fun icon
    name: "Rocket Ship",                // Product name
    description: "A cool rocket toy!",  // What is it?
    price: 6.00,                        // Cost in dollars
    category: "Toys",                   // Group it belongs to
    printTime: "3 hours"                // How long to print
}
```

### Changing the Base Color
The **base color** is included free with all orders. To change it:

1. Go to Admin → Settings
2. Select a new base color from the dropdown
3. That color's upcharge becomes $0

Or edit `js/data.js`:
```javascript
const DEFAULT_BASE_COLOR = "White";  // Change to your most common filament
```

### Changing Color Prices
Edit the `DEFAULT_COLORS` array in `js/data.js`:

```javascript
{ name: "Red", hex: "#EF4444", upcharge: 1.00 },  // Change upcharge amount
```

---

## 💾 How Data is Stored

This app uses **localStorage** (browser storage). This means:
- ✅ Works without a server
- ✅ Data persists between visits
- ⚠️ Data is per-browser (not shared between devices)
- ⚠️ Clearing browser data erases orders

**For a real production shop**, you'd want a backend database. We'll add that in Phase 2!

---

## 🛠️ Development Roadmap

### Phase 1: Static Shop ✅
- [x] Product catalog
- [x] Shopping cart
- [x] Color selection with pricing
- [x] Order submission
- [x] Admin panel
- [x] GitHub Pages hosting

### Phase 2: AI Features (Coming Soon!)
- [ ] AI product recommendations
- [ ] Chat assistant for help
- [ ] Auto-generate product descriptions
- [ ] Smart search

### Phase 3: Backend (Future)
- [ ] Real database
- [ ] User accounts
- [ ] Email notifications
- [ ] Payment processing

---

## 🧑‍🎓 For Educators

This project is designed for teaching:
- **HTML**: Page structure (`index.html`, `admin.html`)
- **CSS**: Styling and layout (`css/style.css`)
- **JavaScript**: Interactivity (`js/app.js`, `js/admin.js`)
- **Data structures**: Arrays and objects (`js/data.js`)
- **Version control**: Git and GitHub
- **Web hosting**: GitHub Pages

### Lesson Ideas
1. **Change the colors** - Have kids edit the CSS variables
2. **Add a product** - Practice editing JavaScript objects
3. **New feature** - Add a "favorites" button
4. **Bug hunt** - Introduce a bug and have them find it

---

## 🤝 Contributing

This is a learning project! Students are encouraged to:
1. Fork the repository
2. Make improvements
3. Submit pull requests

---

## 📝 License

MIT License - Use this however you want!

---

Made with 💜 for Maryland Schools | Let's GrOw! 🚀
