/* ==========================================
   🎮 DATA FILE - EDIT THIS TO ADD PRODUCTS!
   
   Hey kids! 👋 This is where you add new 
   items to the shop. It's easy!
   
   Just copy an existing product and change
   the values. Don't forget the comma!
   ========================================== */

// ========== DEFAULT PRODUCTS ==========
// These are the starter products. You can edit these
// or add new ones in the Admin panel!

const DEFAULT_PRODUCTS = [
    {
        id: 1,
        emoji: "📱",
        name: "Phone Stand",
        description: "Universal phone/tablet stand with adjustable angle",
        price: 5.00,
        category: "Tech",
        printTime: "2 hours"
    },
    {
        id: 2,
        emoji: "✏️",
        name: "Pencil Holder",
        description: "Desktop organizer holds 12+ pencils and pens",
        price: 4.00,
        category: "School",
        printTime: "1.5 hours"
    },
    {
        id: 3,
        emoji: "🔑",
        name: "Keychain",
        description: "Custom letter keychain - tell us your initial!",
        price: 2.50,
        category: "Accessories",
        printTime: "30 min"
    },
    {
        id: 4,
        emoji: "🎧",
        name: "Headphone Hook",
        description: "Under-desk mount for your headphones",
        price: 3.50,
        category: "Tech",
        printTime: "1 hour"
    },
    {
        id: 5,
        emoji: "📖",
        name: "Bookmark",
        description: "Corner bookmark that won't fall out",
        price: 1.50,
        category: "School",
        printTime: "20 min"
    },
    {
        id: 6,
        emoji: "🎲",
        name: "Fidget Cube",
        description: "Print-in-place fidget toy - no assembly needed!",
        price: 4.50,
        category: "Toys",
        printTime: "2 hours"
    }
];


// ========== COLORS ==========
// The first color is the BASE color (free!)
// Other colors have an upcharge

const DEFAULT_COLORS = [
    { name: "Gray",   hex: "#6B7280", upcharge: 0 },
    { name: "White",  hex: "#F3F4F6", upcharge: 0.50 },
    { name: "Black",  hex: "#1F2937", upcharge: 0.50 },
    { name: "Red",    hex: "#EF4444", upcharge: 1.00 },
    { name: "Blue",   hex: "#3B82F6", upcharge: 1.00 },
    { name: "Green",  hex: "#22C55E", upcharge: 1.00 },
    { name: "Yellow", hex: "#EAB308", upcharge: 1.00 },
    { name: "Purple", hex: "#A855F7", upcharge: 1.50 },
    { name: "Orange", hex: "#F97316", upcharge: 1.50 },
    { name: "Pink",   hex: "#EC4899", upcharge: 1.50 }
];


// ========== SETTINGS ==========
// Which color is the "base" free color?
const DEFAULT_BASE_COLOR = "Gray";


/* ==========================================
   ⚠️ DON'T EDIT BELOW THIS LINE! ⚠️
   
   This code loads saved data from the browser.
   The Admin panel saves changes here.
   ========================================== */

// Load from localStorage or use defaults
function loadData(key, defaultValue) {
    try {
        const saved = localStorage.getItem(key);
        return saved ? JSON.parse(saved) : defaultValue;
    } catch (e) {
        console.error('Error loading ' + key, e);
        return defaultValue;
    }
}

// Save to localStorage
function saveData(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        console.error('Error saving ' + key, e);
    }
}

// Initialize data
let products = loadData('printshop_products', DEFAULT_PRODUCTS);
let colors = loadData('printshop_colors', DEFAULT_COLORS);
let baseColorName = loadData('printshop_basecolor', DEFAULT_BASE_COLOR);
let orders = loadData('printshop_orders', []);

// Get the base color object
function getBaseColor() {
    return colors.find(c => c.name === baseColorName) || colors[0];
}

// Get all categories from products
function getCategories() {
    const cats = [...new Set(products.map(p => p.category).filter(Boolean))];
    return ['All', ...cats.sort()];
}

// Generate next product ID
function getNextProductId() {
    if (products.length === 0) return 1;
    return Math.max(...products.map(p => p.id)) + 1;
}

// Generate next order ID
function getNextOrderId() {
    if (orders.length === 0) return 1;
    return Math.max(...orders.map(o => o.id)) + 1;
}
