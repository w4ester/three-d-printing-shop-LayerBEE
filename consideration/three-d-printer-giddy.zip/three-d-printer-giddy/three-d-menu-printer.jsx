import React, { useState } from 'react';
import { ShoppingCart, Package, Check, Plus, Minus, X, ChevronRight } from 'lucide-react';

// Product Catalog - Add your actual items here
const PRODUCTS = [
  { 
    id: 1, 
    name: 'Phone Stand', 
    description: 'Universal phone/tablet stand with adjustable angle',
    price: 5.00,
    emoji: '📱',
    printTime: '2 hrs',
    category: 'Tech'
  },
  { 
    id: 2, 
    name: 'Pencil Holder', 
    description: 'Desktop organizer holds 12+ pencils/pens',
    price: 4.00,
    emoji: '✏️',
    printTime: '1.5 hrs',
    category: 'School'
  },
  { 
    id: 3, 
    name: 'Cable Organizer', 
    description: 'Desk clip for charging cables - set of 3',
    price: 3.00,
    emoji: '🔌',
    printTime: '45 min',
    category: 'Tech'
  },
  { 
    id: 4, 
    name: 'Keychain (Custom Initial)', 
    description: 'Personalized letter keychain - specify letter in notes',
    price: 2.50,
    emoji: '🔑',
    printTime: '30 min',
    category: 'Accessories'
  },
  { 
    id: 5, 
    name: 'Bookmark', 
    description: 'Flexible corner bookmark - won\'t fall out',
    price: 1.50,
    emoji: '📖',
    printTime: '20 min',
    category: 'School'
  },
  { 
    id: 6, 
    name: 'Mini Planter', 
    description: 'Succulent-sized desktop planter with drainage',
    price: 6.00,
    emoji: '🌱',
    printTime: '3 hrs',
    category: 'Home'
  },
  { 
    id: 7, 
    name: 'Fidget Cube', 
    description: 'Print-in-place fidget toy - no assembly',
    price: 4.50,
    emoji: '🎲',
    printTime: '2 hrs',
    category: 'Toys'
  },
  { 
    id: 8, 
    name: 'Headphone Hook', 
    description: 'Under-desk mount for headphones',
    price: 3.50,
    emoji: '🎧',
    printTime: '1 hr',
    category: 'Tech'
  },
];

// Color options - BASE_COLOR is free, others have upcharge
const BASE_COLOR = 'Gray';
const COLORS = [
  { name: 'Gray', hex: '#6B7280', upcharge: 0 },
  { name: 'White', hex: '#F3F4F6', upcharge: 0.50 },
  { name: 'Black', hex: '#1F2937', upcharge: 0.50 },
  { name: 'Red', hex: '#EF4444', upcharge: 1.00 },
  { name: 'Blue', hex: '#3B82F6', upcharge: 1.00 },
  { name: 'Green', hex: '#22C55E', upcharge: 1.00 },
  { name: 'Yellow', hex: '#EAB308', upcharge: 1.00 },
  { name: 'Purple', hex: '#A855F7', upcharge: 1.50 },
  { name: 'Orange', hex: '#F97316', upcharge: 1.50 },
  { name: 'Pink', hex: '#EC4899', upcharge: 1.50 },
];

export default function PrintShop() {
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);
  const [quantity, setQuantity] = useState(1);
  const [customerInfo, setCustomerInfo] = useState({ name: '', email: '', notes: '' });
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [filter, setFilter] = useState('All');

  const categories = ['All', ...new Set(PRODUCTS.map(p => p.category))];

  const filteredProducts = filter === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === filter);

  const addToCart = () => {
    if (!selectedProduct) return;
    const cartItem = {
      id: Date.now(),
      product: selectedProduct,
      color: selectedColor,
      quantity,
      itemTotal: (selectedProduct.price + selectedColor.upcharge) * quantity
    };
    setCart([...cart, cartItem]);
    setSelectedProduct(null);
    setQuantity(1);
    setSelectedColor(COLORS[0]);
  };

  const removeFromCart = (itemId) => {
    setCart(cart.filter(item => item.id !== itemId));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.itemTotal, 0);

  const placeOrder = (e) => {
    e.preventDefault();
    // Here you'd send to your backend
    console.log('Order placed:', { customer: customerInfo, items: cart, total: cartTotal });
    setOrderPlaced(true);
    setCart([]);
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20 text-center max-w-md">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-3">Order Received!</h1>
          <p className="text-white/70 mb-6">
            Thanks {customerInfo.name}! We'll email you at {customerInfo.email} when your prints are ready for pickup.
          </p>
          <button
            onClick={() => {
              setOrderPlaced(false);
              setCustomerInfo({ name: '', email: '', notes: '' });
            }}
            className="px-6 py-3 bg-blue-500 hover:bg-blue-400 text-white font-medium rounded-xl transition-colors"
          >
            Place Another Order
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/30 backdrop-blur-sm border-b border-white/10 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-xl">
                <Package className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">3D Print Shop</h1>
                <p className="text-blue-400 text-sm">School MakerSpace</p>
              </div>
            </div>
            <button
              onClick={() => setShowCart(true)}
              className="relative flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              <span className="font-medium">Cart</span>
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full text-sm font-bold flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Color Legend */}
      <div className="bg-black/20 border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4 text-sm">
            <span className="text-white/60">Colors:</span>
            <span className="flex items-center gap-1">
              <span className="w-4 h-4 rounded-full" style={{ backgroundColor: COLORS[0].hex, border: '2px solid rgba(255,255,255,0.3)' }}></span>
              <span className="text-green-400 font-medium">{BASE_COLOR} = Base (included)</span>
            </span>
            <span className="text-white/40">|</span>
            <span className="text-yellow-400">Special colors = +$0.50 - $1.50</span>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === cat
                  ? 'bg-blue-500 text-white'
                  : 'bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <main className="max-w-6xl mx-auto px-4 pb-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredProducts.map(product => (
            <button
              key={product.id}
              onClick={() => {
                setSelectedProduct(product);
                setSelectedColor(COLORS[0]);
                setQuantity(1);
              }}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/10 hover:border-blue-500/50 hover:bg-white/15 transition-all text-left group"
            >
              <div className="text-5xl mb-3 group-hover:scale-110 transition-transform">{product.emoji}</div>
              <h3 className="text-white font-semibold text-lg">{product.name}</h3>
              <p className="text-white/50 text-sm mt-1 line-clamp-2">{product.description}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-2xl font-bold text-blue-400">${product.price.toFixed(2)}</span>
                <span className="text-white/40 text-xs">{product.printTime}</span>
              </div>
              <div className="mt-2 flex items-center gap-1 text-blue-400 text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Select</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </button>
          ))}
        </div>
      </main>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedProduct(null)}>
          <div className="bg-slate-800 rounded-3xl p-6 max-w-lg w-full border border-white/20" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-4">
              <div className="text-6xl">{selectedProduct.emoji}</div>
              <button onClick={() => setSelectedProduct(null)} className="text-white/50 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <h2 className="text-2xl font-bold text-white">{selectedProduct.name}</h2>
            <p className="text-white/60 mt-1">{selectedProduct.description}</p>
            
            <div className="mt-6">
              <label className="block text-white/80 text-sm font-medium mb-3">Choose Color</label>
              <div className="grid grid-cols-5 gap-2">
                {COLORS.map(color => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`relative p-1 rounded-xl transition-all ${
                      selectedColor.name === color.name 
                        ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-800' 
                        : 'hover:scale-105'
                    }`}
                  >
                    <div 
                      className="w-full aspect-square rounded-lg border-2 border-white/20"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-xs text-white/70 mt-1 block text-center">{color.name}</span>
                    {color.upcharge === 0 ? (
                      <span className="text-xs text-green-400 block text-center">Base</span>
                    ) : (
                      <span className="text-xs text-yellow-400 block text-center">+${color.upcharge.toFixed(2)}</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-white/80 text-sm font-medium mb-3">Quantity</label>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <span className="text-2xl font-bold text-white w-12 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(10, quantity + 1))}
                  className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="mt-6 p-4 bg-black/30 rounded-xl">
              <div className="flex justify-between text-white/60 text-sm">
                <span>Base price</span>
                <span>${selectedProduct.price.toFixed(2)}</span>
              </div>
              {selectedColor.upcharge > 0 && (
                <div className="flex justify-between text-yellow-400 text-sm mt-1">
                  <span>{selectedColor.name} color</span>
                  <span>+${selectedColor.upcharge.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-white/60 text-sm mt-1">
                <span>× {quantity}</span>
                <span></span>
              </div>
              <div className="flex justify-between text-white font-bold text-xl mt-3 pt-3 border-t border-white/10">
                <span>Total</span>
                <span>${((selectedProduct.price + selectedColor.upcharge) * quantity).toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={addToCart}
              className="w-full mt-4 py-4 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-400 hover:to-purple-400 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <ShoppingCart className="w-5 h-5" />
              Add to Cart
            </button>
          </div>
        </div>
      )}

      {/* Cart Sidebar */}
      {showCart && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50" onClick={() => setShowCart(false)}>
          <div 
            className="absolute right-0 top-0 h-full w-full max-w-md bg-slate-800 border-l border-white/20 overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Your Cart</h2>
                <button onClick={() => setShowCart(false)} className="text-white/50 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="text-center py-12 text-white/40">
                  <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>Your cart is empty</p>
                </div>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {cart.map(item => (
                      <div key={item.id} className="bg-black/30 rounded-xl p-4 flex gap-4">
                        <div className="text-4xl">{item.product.emoji}</div>
                        <div className="flex-1">
                          <h3 className="text-white font-medium">{item.product.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span 
                              className="w-4 h-4 rounded-full border border-white/30" 
                              style={{ backgroundColor: item.color.hex }}
                            />
                            <span className="text-white/50 text-sm">{item.color.name}</span>
                            <span className="text-white/50 text-sm">× {item.quantity}</span>
                          </div>
                          <p className="text-blue-400 font-semibold mt-1">${item.itemTotal.toFixed(2)}</p>
                        </div>
                        <button 
                          onClick={() => removeFromCart(item.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-white/10 pt-4 mb-6">
                    <div className="flex justify-between text-2xl font-bold text-white">
                      <span>Total</span>
                      <span>${cartTotal.toFixed(2)}</span>
                    </div>
                  </div>

                  <form onSubmit={placeOrder} className="space-y-4">
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">Your Name *</label>
                      <input
                        type="text"
                        required
                        value={customerInfo.name}
                        onChange={e => setCustomerInfo({...customerInfo, name: e.target.value})}
                        className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-blue-500"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">Email *</label>
                      <input
                        type="email"
                        required
                        value={customerInfo.email}
                        onChange={e => setCustomerInfo({...customerInfo, email: e.target.value})}
                        className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-blue-500"
                        placeholder="you@school.edu"
                      />
                    </div>
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">Notes (optional)</label>
                      <textarea
                        value={customerInfo.notes}
                        onChange={e => setCustomerInfo({...customerInfo, notes: e.target.value})}
                        className="w-full px-4 py-3 bg-black/30 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-blue-500 h-20"
                        placeholder="Custom initial for keychain? Special requests?"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white font-bold rounded-xl transition-all"
                    >
                      Place Order - ${cartTotal.toFixed(2)}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
